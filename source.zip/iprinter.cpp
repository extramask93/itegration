#include "iprinter.h"

IPrinter::IPrinter()
{

}
